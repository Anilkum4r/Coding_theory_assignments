%---------------------------------
% Assignment #2
%Anil Kumar
%2023JTM2567
%---------------------------------
%% clear workplace
%%

clc;
clear;
clearvars;

%% Implimentation of given convolution coder
%%

ip= [0 1 0 0 1 1 0 1 0 0];   %input bit stream
c_s = [0, 0];  %current state initialize with 0 0
cd = [];   %code word

m=length(ip);
for k = 1:m
    [n_s, op] = s_trans(c_s, ip(k));  %n_s is next state and op is the output
    cd = [cd, op]; 
    c_s = n_s; 
end

disp('The generated codeword  is ->');
disp('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^');
disp(cd);
disp('^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^');

%% Call state transition diagram function and trellis function
%%
plt_trans_diagram();
plotTrellisDiagram(ip);


%% declaration of functions 


%% 1.state transition logic
%%


function [n_s, op] = s_trans(c_s, ip)
    d1 = c_s(1); % d_{k-1}
    d2 = c_s(2); % d_{k-2}
    k=xor(d1,d2);  % intermediate node
    d1_n = xor(k,ip);  %next state variables
    d2_n =d1;          
    n_s = [d1_n, d2_n];   %next state
  %outputs
    v1 = ip; 
    v2 = xor(d1_n, d2);
    op = [v1, v2];
end

%% 2. State Transition diagram plotting function
%%
function plt_trans_diagram()
    states = [0 0; 0 1; 1 0; 1 1];
    inputs = [0, 1];
    G = digraph();
    ed_lbl = {};
    nd_lbl = {'00', '10', '01', '11'};  
    
    x_pos = [2, 1, 3, 2];  % Adjust as needed for alignment
    y_pos = [1, 2, 2, 3];  % Adjust as needed for alignment
    
    sz=size(states, 1);
    ip_len=length(inputs);
    
    for i = 1:sz
        for j = 1:ip_len
            c_s = states(i, :);  % Current state
            ip = inputs(j);      % Input
            [n_s, op] = s_trans(c_s, ip);  % Next state and output
            
            s_n = sprintf('%d%d', c_s(1), c_s(2));
            e_n = sprintf('%d%d', n_s(1), n_s(2));
            
            G = addedge(G, s_n, e_n);
            ed_lbl = [ed_lbl; {sprintf('%d -> [%d%d]', ip, op(1), op(2))}];
        end
    end

    figure;
    p = plot(G, 'NodeLabel', nd_lbl, 'EdgeLabel', ed_lbl);
    p.XData = x_pos;
    p.YData =y_pos;
    title('State transition');
end


%% 3. Trellis diagram plotting function
%%
function plotTrellisDiagram(ip)

    st_lbl = {'00', '10', '01', '11'};
    
    states = [0 0; 1 0; 0 1; 1 1];
    c_s = [0 0]; % Initial state
    m = length(ip);
    
    y_positions = [4, 3, 2, 1];  % y positions in binary
    
    figure;
    hold on;
    
    for i = 1:m
       
        current_input = ip(i);
        start_idx = find(ismember(states, c_s, 'rows'));
        [n_s, op] = s_trans(c_s, current_input);  % Next state and output
        end_idx = find(ismember(states, n_s, 'rows'));
        plot([i, i+1], [y_positions(start_idx), y_positions(end_idx)], 'o-',LineWidth=2);
        text(i, y_positions(start_idx), st_lbl{start_idx}, 'VerticalAlignment', 'bottom');
        edge_label = sprintf('I/p: %d, O/p: [%d%d]', current_input, op(1), op(2));
        mid_x = (i + (i + 1)) / 2;
        mid_y = (y_positions(start_idx) + y_positions(end_idx)) / 2;
        text(mid_x, mid_y, edge_label, 'HorizontalAlignment', 'center', 'Color', 'blue');
        
     
        c_s = n_s;   %update state
    end
    set(gca, 'YTick', y_positions, 'YTickLabel', st_lbl);
    title('Trellis Diagram');
    xlabel('Time');
    ylabel('States');
    hold off;
end

