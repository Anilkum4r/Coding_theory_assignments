%---------------------------------
% Assignment #2
%Anil Kumar
%2023JTM2567
%---------------------------------

%% Received data sequence (given in question)
%%
clc;
clear;
clearvars;

rx_data = [1 1 1 0 0 0 0 1 0 1 1 1];

% Define the trellis structure
n_state = 4; % 4 states (00, 01, 10, 11)  
n_time_steps = length(rx_data) / 2; % Number of time steps for the received sequence

% State transitions in which rows represents the current states 0->00 1->01 2->10 3->11 and columns
% represents  the inputs in 0 and 1

s_tr = [1, 3; % From state 0 (00) 
        1, 3; % From state 1 (01)
        2, 4; % From state 2 (10)
        2, 4  % From state 3 (11)
       ];

% Output matrix based on state transitions:
% Each entry corresponds to [y1, y2] for the transition from the state given input
outputMatrix = [
    0 0; 1 1; % From state 0 (00): input 0 -> 00, input 1 -> 11
    1 1; 0 0; % From state 1 (01): input 0 -> 11, input 1 -> 00
    1 0; 0 1; % From state 2 (10): input 0 -> 10, input 1 -> 01
    0 1; 1 0  % From state 3 (11): input 0 -> 01, input 1 -> 10
];

%% matrix initialization 
%%

path_mat = inf(n_state, n_time_steps + 1); %path matrix
survivorPaths = zeros(n_state, n_time_steps);

% starting state of path matrix -> 00
path_mat(1, 1) = 0;

% Convert received data to binary pairs
rx_pair= reshape(rx_data, 2, [])';

%% Viterbi algorithm
%%
for t = 1:n_time_steps
    for currentState = 1:n_state
        for input = 1:2 % 1 -> input 0, 2 -> input 1
            nextState = s_tr(currentState, input);
            % Determine the expected output
            op_idx= (currentState - 1) * 2 + input;
            expected_op = outputMatrix(op_idx, :);
            
            % Calculate the Hamming distance
            metric = sum(expected_op ~= rx_pair(t, :));
            
            % Update path metric
            currentMetric = path_mat(currentState, t) + metric;
            if currentMetric < path_mat(nextState, t + 1)
                path_mat(nextState, t + 1) = currentMetric;
                survivorPaths(nextState, t) = currentState;
            end
        end
    end
end

% Backtrace to find the most likely path
[~, finalState] = min(path_mat(:, end));
decodedPath = zeros(1, n_time_steps + 1);
decodedPath(end) = finalState;

for t = n_time_steps:-1:1
    decodedPath(t) = survivorPaths(decodedPath(t + 1), t);
end

%% Conversion of state transition to decoded bits 
%%

decodedData = zeros(1, n_time_steps);
for t = 2:n_time_steps + 1
    prevState = decodedPath(t - 1);
    currentState = decodedPath(t);
    % Determine the input that causes the transition from prevState to currentState
    if s_tr(prevState, 1) == currentState
        decodedData(t - 1) = 0;
    elseif s_tr(prevState, 2) == currentState
        decodedData(t - 1) = 1;
    end
end
%% Display of decoded data 
%%

disp('Decoded Data is :- ');
disp('***************************************************************');
disp(decodedData);
disp('****************************************************************');