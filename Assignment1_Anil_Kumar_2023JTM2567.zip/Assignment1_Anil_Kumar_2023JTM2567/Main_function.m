    %Assignment #1
    %ELL710  (Coding Theory)
    % Anil Kumar (2023JTM2567)

    %% RS Code Encoder & Decoder (Construct GF)
    %%
    clear;
    clc;
    
    
    errcnt = input('Give number of errors (Max 3 errors can be corrected by this code) : \n');

    p = 2;  %prime
    m = 4;
    poly = [1 1 0 0 1]; %p^m  prime polynomial
    fprintf('Constructing GF(2^%d) powers table..\n', m);
    fprintf('Prime polynomial:\n');
    disp(poly);
    fprintf('Prime element: %d\n', p);
    
    %% calculation of power table in GF(2^m) start
    %% 
   
    %GF_CALCULATE_PT Computes powers table for GF(2^m) built over p polynomial "gf_poly" and for specified p element
    %GF(2) powers table

    binary_field_pts = [0 1 -1; 1 1 0];
    gf_size = 2^m;
    gf_pt = zeros(gf_size, 3);
    gf_pt(1,:) = [0 1 -1];
    gf_pt(:,3) = -1;
    poly_pe = de2bi(p, m);  %Polynomial representation of "p"
    cur_res = poly_pe;
    for i=1:(gf_size-1)
        dec_cur_res = bi2de(cur_res);   %Decimal representation of p^i rs_dminrs_dmin
        gf_pt(i+1, 1) = i;
        gf_pt(i+1, 2) = dec_cur_res;
        gf_pt(dec_cur_res+1, 3) = i;
        %Calculate p^(i+1) modulo "gf_poly"
        [cur_res, ~] = poly_div(poly_mul(cur_res, poly_pe, binary_field_pts, 2),poly, binary_field_pts, 2);
    end
    fprintf('Galois Field constructed successfully\n');
    
    
    %% Reed Solemon generator calculation starts 
    %%

    dmin = 9;
    fprintf('Calculating Reed Solemon generator polynomial\n');
    fprintf('Prime used to construct G: %d, Dmin: %d\n',p, dmin);
    rs_poly = [p 1];   % G = x +p
    cur_res = gf_mul(p,p, gf_pt, gf_size);
    cur_pow = 2;
    r = 1;
    while cur_res ~=p
        if cur_pow < dmin
            %If we've achieved specified dmin, stop to grow polynomial
            rs_poly = poly_mul(rs_poly, [cur_res 1], gf_pt, gf_size);
            r = r + 1;
        end
        % Computation of N
        cur_res = gf_mul(cur_res,p, gf_pt, gf_size);
        cur_pow = cur_pow + 1;
    end
    
    n = cur_pow - 1;    % N = q-1
    k = n - r;          

    fprintf('Constructed code N=%d K=%d R=%d over GF(%d)\n', n, k ,r, gf_size);
    fprintf('G(x): ');
    disp(rs_poly);

   %% Reed Solemon encoding starts 
   %%

    fprintf('--------------------\n ENCODING...\n-------------------\n');
    data = randi(gf_size, 1, k) - 1;
    fprintf('Size of message symbols (Random) to encode(%d symbols): ', k);
    fprintf('Message symbols are: ');
    disp(data);
    
    k = n - length(rs_poly) + 1;
    if length(data) ~= k
        error('Data block length must be equal to %d', k);
    end
    codeword  = [zeros(1, length(rs_poly) - 1) data(end:-1:1)];
    [rem, ~] = poly_div(codeword , rs_poly, gf_pt, gf_size);
    codeword (1:length(rem)) = rem;

    fprintf('Encoded codeword (%d symbols):\n', n);
    disp(codeword);

    %% Error introduction 
    %%

    % errcnt = floor((dmin - 1)/2);
    % errcnt = 6;

    
    fprintf('----------------------------------------------\n CORRUPT WITH ERROR...\n--------------------------------------------------------\n');
    fprintf('Randomized error vector:\n');
    errv = zeros(1,n);
    % for i=1:errcnt
    %     errv(randi(n, 1)) = randi(gf_size - 1, 1);
    % end
    error_positions = randperm(n, errcnt);  % Generate errcnt unique positions
    for i=1:errcnt
    errv(error_positions(i)) = randi(gf_size - 1, 1);  % Place error at unique positions
    end
    disp(errv);
    real_errcnt = 0;
    for i=1:length(errv)
        if errv(i) ~= 0
            real_errcnt = real_errcnt + 1;
        end
    end
    fprintf('Real error count: %d\n', real_errcnt);
    cw_t = codeword;
    cw_t = bitxor(codeword, errv);
    fprintf('Corrupted codeword:\n');
    disp(cw_t);

    %% Decoding Starts
    %%

    fprintf('-------------------------------------\n DECODEING....\n-----------------------------------------------------\n');
    tic;
   
    [rdata, rcorrect, err_present, S, ccw] = rs_decode(cw_t,p, rs_poly, n, gf_pt, gf_size);
    
    etime = toc;
    fprintf('Syndrome vector:');
    disp(S);
    if err_present
        fprintf('Decoder detected error presence\n');
    else
        fprintf('Decoder hasnt detected any errors\n');
    end
    if rcorrect
        fprintf('Decoder thinks that we have correct data..\n');
        fprintf('Recovered data:\n');
        disp(rdata);
        rec_errv = bitxor(rdata, data);
        fprintf('Errors in recovered data:\n');
        disp(rec_errv);
        if nnz(rec_errv) == 0
            fprintf('-------------------------\n DECODING SUCCESSFUL \n--------------------------\n');
        else
            fprintf('----------------------\n SOMETHING WENT WRONG \n---------------------------\n');
            [rem, ~] = poly_div(ccw, rs_poly, gf_pt, gf_size);
            if rem == 0
                fprintf('..But decoder has given us another code word!\n');
            else
                fprintf('..And decoder produced some weird thing..\n');
            end
        end
    else
        fprintf('Decoder cannot recover data\n');
    end
    fprintf('DECODE spent %d seconds\n', etime);



