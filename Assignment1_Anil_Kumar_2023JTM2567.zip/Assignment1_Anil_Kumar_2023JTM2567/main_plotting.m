%Assignment #1
%ELL710  (Coding Theory)
% Anil Kumar (2023JTM2567)

%% RS Code Encoder & Decoder (Construct GF)
%%
clear; clc;


p = 2;  % Prime element
m = 4;  % GF(2^m)
poly = [1 1 0 0 1];  % Prime polynomial
dmin = 9;  % Minimum distance for RS code


%GF(2^m) powers table calculation
binary_field_pts = [0 1 -1; 1 1 0];
gf_size = 2^m;
gf_pt = zeros(gf_size, 3);
gf_pt(1,:) = [0 1 -1];
gf_pt(:,3) = -1;
poly_pe = de2bi(p, m);  % Polynomial representation of "p"
cur_res = poly_pe;
for i = 1:(gf_size-1)
    dec_cur_res = bi2de(cur_res);  % Decimal representation of p^i
    gf_pt(i+1, 1) = i;
    gf_pt(i+1, 2) = dec_cur_res;
    gf_pt(dec_cur_res+1, 3) = i;
    % Calculate p^(i+1) modulo "gf_poly"
    [cur_res, ~] = poly_div(poly_mul(cur_res, poly_pe, binary_field_pts, 2), poly, binary_field_pts, 2);
end


% Reed-Solomon generator polynomial calculation
rs_poly = [p 1];  % G(x) = x + p
cur_res = gf_mul(p, p, gf_pt, gf_size);
cur_pow = 2;
r = 1;
while cur_res ~= p
    if cur_pow < dmin
        % Stop if specified dmin is reached
        rs_poly = poly_mul(rs_poly, [cur_res 1], gf_pt, gf_size);
        r = r + 1;
    end
    % Computation of N
    cur_res = gf_mul(cur_res, p, gf_pt, gf_size);
    cur_pow = cur_pow + 1;
end

n = cur_pow - 1;    % N = q-1
k = n - r;          % K = N - R
fprintf('Constructed code N=%d K=%d R=%d over GF(%d)\n', n, k, r, gf_size);
fprintf('G(x): ');
disp(rs_poly);

%% Error introduction
max_errcnt = 9; 
itr = 1000;  
det_prob = zeros(1, max_errcnt);  

for errcnt = 1:max_errcnt
    correct_detections = 0;
    
    for ii = 1:itr
        %% Reed-Solomon encoding
        data = randi(gf_size, 1, k) - 1;  % Random message
        codeword = [zeros(1, length(rs_poly) - 1), data(end:-1:1)];
        [rem, ~] = poly_div(codeword, rs_poly, gf_pt, gf_size);
        codeword(1:length(rem)) = rem;
        
        %% Introduce errors
        errv = zeros(1, n);
        error_positions = randperm(n, errcnt);  
        for i = 1:errcnt
            errv(error_positions(i)) = randi(gf_size - 1, 1);  % Introduce random errors
        end
        cw_t = bitxor(codeword, errv);  % Corrupted codeword

        %% Decode the corrupted codeword
        [rdata, rcorrect, err_present, ~, ~] = rs_decode(cw_t, p, rs_poly, n, gf_pt, gf_size);
        
        % Check if the decoding is successful (no errors after correction)
        rec_errv = bitxor(rdata, data);
        if nnz(rec_errv) == 0  % No errors in recovered data
            correct_detections = correct_detections + 1;
        end
    end
    
    % probability of error detection
    det_prob(errcnt) = correct_detections / itr;
end

%% Plotting the results
figure;
plot(1:max_errcnt, det_prob, '-o', 'LineWidth', 2);
xlabel('Number of symbol errors introduced');
ylabel('Probability of error correction');
grid on;
